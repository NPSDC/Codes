#include <stdio.h>
#include <unistd.h>
#include <pwd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <wait.h>
#define MAX 1024

void print(char *arr[], int l)
{
	int i;
	for(i = 0; i < l ; i++)
		printf("%s ", arr[i]);
	printf("\n");
}

int main()
{
	pid_t pid, pid2;
	int i,j,k, flag;
	int fd[2], prevfd[2];
	char *commands[MAX]; //structure  given by user			
	char *commands1[MAX];
	char *token;
	char arr[MAX];
	while(1)
	{
		scanf(" %[^\n]s",arr);
		token = strtok(arr, " ");
		i = 0;
		k = 0;
		flag = 0;
		while(token != NULL)
		{
			commands[i] = token;
			token = strtok(NULL, " ");
			i++;
		}

		for(j = 0; j < i; j++)
		{
			if(strcmp(commands[j], "|") == 0)
			{
				k = 0;
				if(j != 0)
				{
					if (pipe(fd) < 0)
						perror("pipe error\n");	
					
					
					//prevfd[0] = dup(0);
					//prevfd[1] = dup(1);
					pid = fork();			
					if(pid == 0)
					{
						if(flag == 1)
						{
						close(prevfd[1]);
						dup2(prevfd[0], 0);
						}
						close(fd[0]);
						dup2(fd[1], 1);	
						execvp(commands1[0], commands1);
					}
					else
					{
						wait(NULL);		
						close(prevfd[1]);				
						prevfd[0] = fd[0];
						prevfd[1] = fd[1];

					}
					if(flag == 0)
						flag = 1;
				}
				continue;
			}
				commands1[k] = commands[j];
				k++;
		}
		
		
		
		/*else
		{
			wait(NULL);
			close(fd[1]);
			dup2(fd[0], 0);
 			pid2 = fork();
			if(pid2 == 0)
			{			
				//dup2(prevfd[1], 1);
				execl("/usr/bin/wc", "wc", NULL);
			}
			else
			{
				wait(0);		
			}			
		}*/
		
	}
	return 0;
}